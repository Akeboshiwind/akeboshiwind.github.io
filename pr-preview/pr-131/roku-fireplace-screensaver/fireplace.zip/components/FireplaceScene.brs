' Builds the scene from pkg:/config/layers.json, the same file Blender rendered the layers from.
' Layers are listed back to front. Consecutive layers with the same parallax share one drifting Group, so
' they move as one, to the pixel; and every drift is driven by one Animation, so the groups move in the
' same frame and never stutter against each other.

sub init()
    m.scene = ParseJson(ReadAsciiFile("pkg:/config/layers.json"))
    m.margin = m.scene.canvas.margin
    m.canvas = [m.scene.design.w + 2 * m.margin, m.scene.design.h + 2 * m.margin]
    m.world = m.top.findNode("world")
    m.crops = ParseJson(ReadAsciiFile("pkg:/config/crops.json"))
    m.loading = 0
    m.built = false
    m.revealed = false
    m.flames = []

    settling = {}
    for each id in m.scene.settle.layers
        settling[id] = true
    end for
    collapsing = {}
    if m.scene.collapse <> invalid
        for each id in m.scene.collapse.layers
            collapsing[id] = true
        end for
        for each id in m.scene.collapse.into
            collapsing[id] = true
        end for
    end if
    settlers = []
    drifts = []
    drifting = invalid
    parallax = invalid
    for each layer in m.scene.layers
        if parallax = invalid or layer.parallax <> parallax
            parallax = layer.parallax
            drifting = CreateObject("roSGNode", "Group")
            drifting.id = "drift" + drifts.count().ToStr()
            m.world.appendChild(drifting)
            drifts.push(driftInterpolator(drifting, parallax))
        end if
        group = CreateObject("roSGNode", "Group")
        group.id = "layer_" + layer.id
        drifting.appendChild(group)
        if settling.DoesExist(layer.id)
            inner = CreateObject("roSGNode", "Group")  ' its own translation, apart from the drift's
            inner.id = "settle_" + layer.id
            group.appendChild(inner)
            settlers.push(inner)
            group = inner
        end if
        if collapsing.DoesExist(layer.id)
            inner = CreateObject("roSGNode", "Group")  ' its own opacity, apart from the firelight's arc
            inner.id = "collapse_" + layer.id
            group.appendChild(inner)
            group = inner
        end if

        if layer.kind = "still" or layer.kind = "vignette"
            group.appendChild(makePoster(layer.file, 0, 0, m.canvas[0], m.canvas[1]))
        else if layer.kind = "glow"
            addGlow(group, layer, layer.rect, layer.file, layer.id)
        else if layer.kind = "firelight"
            canvas = [0, 0, m.canvas[0], m.canvas[1]]
            if layer.regions <> invalid and layer.regions > 1
                ' soft-edged parts of the fire's light, each breathing on its own
                for k = 0 to layer.regions - 1
                    addGlow(group, layer, canvas, layer.file.Replace(".png", "_r" + k.ToStr() + ".png"), layer.id + "_r" + k.ToStr())
                end for
            else
                addGlow(group, layer, canvas, layer.file, layer.id)
            end if
        else if layer.kind = "flipbook"
            addFlames(group, layer)
        else if layer.kind = "clip"
            addClip(group, layer)
        end if
    end for

    if m.scene.drift.ampPx[0] <> 0 or m.scene.drift.ampPx[1] <> 0
        animate(m.top, m.scene.drift.periodSec, "linear", drifts)
    end if
    if settlers.count() > 0 then addSettle(settlers, m.scene.settle)

    addFlare()
    if m.scene.collapse <> invalid then addCollapse()
    if m.flames.count() > 0
        if m.scene.arc <> invalid then startArc()
        m.clock = CreateObject("roTimespan")
        m.flameTimer = CreateObject("roSGNode", "Timer")
        m.flameTimer.repeat = true
        m.flameTimer.duration = 1 / m.flipbook.fps
        m.flameTimer.observeField("fire", "onFlameTick")
        m.top.appendChild(m.flameTimer)
        m.flameTimer.control = "start"
    end if
    m.built = true
    revealWhenLoaded()
end sub

' The room stays dark until every image has loaded, then fades in whole: shown as they load, the fire's
' frames would pop in one by one. Should a TV never report one loaded, it shows after 15 seconds anyway.
sub revealWhenLoaded()
    m.revealWait = CreateObject("roSGNode", "Timer")
    m.revealWait.duration = 15
    m.revealWait.observeField("fire", "reveal")
    m.top.appendChild(m.revealWait)
    m.revealWait.control = "start"
    if m.loading = 0 then reveal()
end sub

sub onPosterLoad(event as object)
    status = event.getData()
    if status <> "ready" and status <> "failed" then return
    event.getRoSGNode().unobserveField("loadStatus")
    m.loading = m.loading - 1
    if m.built and m.loading = 0 then reveal()
end sub

sub reveal()
    if m.revealed then return
    m.revealed = true
    m.revealWait.control = "stop"
    anim = CreateObject("roSGNode", "Animation")
    anim.duration = 1.5
    anim.easeFunction = "inOutSine"
    anim.appendChild(interpolator("FloatFieldInterpolator", "world.opacity", [0.0, 1.0], [0.0, 1.0]))
    m.top.appendChild(anim)
    anim.control = "start"
end sub

' Image `file` drawn in the w by h rect at x, y. The build crops a transparent image to what it draws, so the TV
' holds only that much in memory, `m.crops` saying where in the rect the crop sits.
function makePoster(file as string, x as float, y as float, w as float, h as float) as object
    p = CreateObject("roSGNode", "Poster")
    m.loading = m.loading + 1
    p.observeField("loadStatus", "onPosterLoad")
    p.uri = "pkg:/images/" + file
    c = m.crops[file]
    if c = invalid then c = [0, 0, 1, 1]
    p.translation = [x + c[0] * w, y + c[1] * h]
    p.width = c[2] * w
    p.height = c[3] * h
    p.loadDisplayMode = "scaleToFit"
    return p
end function

' An animation's frames, each loaded once, up front, in a Poster of its own, all hidden: a Poster given a new uri
' shows nothing until the image has loaded, which on a TV takes longer than a frame.
function makeFrames(files as object, w as float, h as float) as object
    g = CreateObject("roSGNode", "Group")
    for each file in files
        p = makePoster(file, 0, 0, w, h)
        p.visible = false
        g.appendChild(p)
    end for
    return g
end function

sub showFrame(frames as object, hide as integer, show as integer)
    if hide >= 0 then frames.getChild(hide).visible = false
    if show >= 0 then frames.getChild(show).visible = true
end sub

function rndRange(r as object) as float
    return r[0] + Rnd(0) * (r[1] - r[0])
end function

sub animate(target as object, duration as float, ease as string, interpolators as object, delay = 0 as float)
    anim = CreateObject("roSGNode", "Animation")
    anim.duration = duration
    anim.delay = delay
    anim.repeat = true
    anim.easeFunction = ease
    for each i in interpolators
        anim.appendChild(i)
    end for
    target.appendChild(anim)
    anim.control = "start"
end sub

function interpolator(nodeType as string, field as string, keys as object, values as object) as object
    i = CreateObject("roSGNode", nodeType)
    i.fieldToInterp = field
    i.key = keys
    i.keyValue = values
    return i
end function

' A slow sway shared by every layer, scaled by how near the layer is: side to side, and a figure-eight
' if drift.ampPx gives it any height. Returns its interpolator, for the one Animation that drives them all.
function driftInterpolator(group as object, parallax as float) as object
    d = m.scene.drift
    samples = 24
    keys = []
    values = []
    for i = 0 to samples
        t = i / samples
        keys.push(t)
        values.push([-m.margin + parallax * d.ampPx[0] * Sin(2 * 3.14159265 * t), -m.margin + parallax * d.ampPx[1] * Sin(4 * 3.14159265 * t)])
    end for
    group.translation = values[0]
    return interpolator("Vector2DFieldInterpolator", group.id + ".translation", keys, values)
end function

' Burning logs settle: now and then they drop a few pixels in a fraction of a second, then creep back up so
' slowly it can't be seen, ready to settle again.
sub addSettle(groups as object, settle as object)
    drop = rndRange(settle.px)
    period = rndRange(settle.periodSec)
    at = 0.3 + Rnd(0) * 0.4  ' when in the loop it settles
    keys = [0.0, at, at + 0.4 / period, 1.0]
    values = [[0, 0], [0, 0], [0, drop], [0, 0]]
    interpolators = []
    for each g in groups
        interpolators.push(interpolator("Vector2DFieldInterpolator", g.id + ".translation", keys, values))
    end for
    animate(m.top, period, "linear", interpolators)
end sub

' A poster whose opacity wanders between random levels, back at full at the end of each loop: the glow,
' and firelight laid over the layer it brightens, so the TV's blend between them is the fire flickering.
sub addGlow(group as object, layer as object, r as object, file as string, id as string)
    p = makePoster(file, r[0], r[1], r[2], r[3])
    p.id = id
    p.opacity = layer.pulse.max
    group.appendChild(p)
    steps = 24
    keys = []
    values = []
    for i = 0 to steps
        keys.push(i / steps)
        if i = 0 or i = steps
            values.push(layer.pulse.max)
        else
            values.push(rndRange([layer.pulse.min, layer.pulse.max]))
        end if
    end for
    animate(m.top, rndRange(layer.pulse.periodSec) * steps, "inOutSine", [interpolator("FloatFieldInterpolator", id + ".opacity", keys, values)])
end sub

' A group's opacity wandering between random levels within `fade`, for ever.
sub addFade(node as object, fade as object)
    steps = 12
    keys = []
    values = []
    first = rndRange([fade.min, fade.max])
    for i = 0 to steps
        keys.push(i / steps)
        if i = 0 or i = steps
            values.push(first)
        else
            values.push(rndRange([fade.min, fade.max]))
        end if
    end for
    node.opacity = first
    animate(m.top, rndRange(fade.periodSec) * steps, "inOutSine", [interpolator("FloatFieldInterpolator", node.id + ".opacity", keys, values)])
end sub

' A frame of the flipbook, or with `loops`, of region `region`'s own loop.
function flameFiles(layer as object, region as integer, length as integer) as object
    files = []
    for frame = 0 to length - 1
        n = Right("0" + frame.ToStr(), 2)
        if region >= 0 then n = "r" + region.ToStr() + "_" + n
        files.push(layer.file.Replace("%02d", n))
    end for
    return files
end function

' The fire: each copy of the flipbook, or with `loops`, each copy of each region's loop, steps on its own,
' the regions' loops of different lengths, so the whole never comes round again.
sub addFlames(group as object, layer as object)
    m.flipbook = layer
    loops = [layer.frames]
    regions = [-1]
    if layer.loops <> invalid and layer.loops.count() > 0
        loops = layer.loops
        regions = []
        for k = 0 to loops.count() - 1
            regions.push(k)
        end for
    end if
    for k = 0 to regions.count() - 1
        addFlameCopies(group, layer, regions[k], loops[k])
    end for
end sub

sub addFlameCopies(group as object, layer as object, region as integer, length as integer)
    r = layer.rect
    for each c in layer.copies
        w = r[2] * c.scale
        h = r[3] * c.scale
        ' copies share the rect's bottom centre, so smaller ones still sit on the logs
        p = makeFrames(flameFiles(layer, region, length), w, h)
        p.translation = [r[0] + (r[2] - w) / 2 + c.dx, r[1] + (r[3] - h) + c.dy]
        frame = c.phase mod length
        showFrame(p, -1, frame)
        p.scaleRotateCenter = [w / 2, h]
        holder = group
        if c.fade <> invalid
            ' its own group, so its slow fade multiplies the flicker rather than fighting it
            holder = CreateObject("roSGNode", "Group")
            holder.id = "flamecopy" + m.flames.count().ToStr()
            group.appendChild(holder)
            addFade(holder, c.fade)
        end if
        holder.appendChild(p)
        m.flames.push({ frames: p, frame: frame, nextFlicker: 0.0, holder: holder, fades: c.fade <> invalid, nextJump: 0.0, region: region, length: length })
    end for
end sub

sub onFlameTick()
    layer = m.flipbook
    fl = layer.flicker
    now = m.clock.TotalMilliseconds() / 1000
    for i = 0 to m.flames.count() - 1
        f = m.flames[i]
        was = f.frame
        ' the frames are a simulation, so they only run forwards; the flipbook loops seamlessly
        f.frame = (f.frame + 1) mod f.length
        ' while a fading copy can't be seen, it jumps to anywhere in the loop: the two copies never meet
        ' the same way twice
        if f.fades and f.holder.opacity < 0.03 and now >= f.nextJump
            f.frame = Rnd(f.length) - 1
            f.nextJump = now + 3
        end if
        showFrame(f.frames, was, f.frame)
        if now >= f.nextFlicker
            f.frames.opacity = rndRange(fl.opacity)
            f.frames.scale = [1.0, rndRange(fl.scaleY)]
            f.nextFlicker = now + rndRange(fl.everySec)
        end if
    end for
end sub

' When a log pops, the room flares with it: its render in the fire's brighter light, laid over the firelight
' layer, brightens for a moment and fades.
sub addFlare()
    m.flare = invalid
    lit = invalid
    for each l in m.scene.layers
        if l.kind = "firelight" and l.of = "hearth" then lit = l
    end for
    if lit = invalid then return
    p = makePoster(lit.file, 0, 0, m.canvas[0], m.canvas[1])
    p.id = "flare"
    p.opacity = 0
    m.world.findNode("layer_" + lit.id).appendChild(p)
    anim = CreateObject("roSGNode", "Animation")
    anim.duration = 1.2
    anim.repeat = false
    anim.easeFunction = "linear"
    anim.appendChild(interpolator("FloatFieldInterpolator", "flare.opacity", [0.0, 0.12, 1.0], [0.0, 0.6, 0.0]))
    m.top.appendChild(anim)
    m.flare = anim
end sub

' The fire builds and dies down over minutes: step by step, each step to a new brightness of firelight chosen
' afresh, so it never takes the same path twice.
sub startArc()
    m.arcLights = []
    for each l in m.scene.layers
        if l.kind = "firelight" then m.arcLights.push(m.world.findNode("layer_" + l.id))
    end for
    m.arcLight = 1.0
    m.arcAnim = CreateObject("roSGNode", "Animation")
    m.arcAnim.repeat = false
    m.arcAnim.easeFunction = "inOutSine"
    m.top.appendChild(m.arcAnim)
    m.arcAnim.observeField("state", "onArcState")
    nextArcStep()
end sub

sub nextArcStep()
    a = m.scene.arc
    light = rndRange(a.light)
    anim = m.arcAnim
    while anim.getChildCount() > 0
        anim.removeChildIndex(0)
    end while
    anim.duration = rndRange(a.periodSec)
    for each g in m.arcLights
        anim.appendChild(interpolator("FloatFieldInterpolator", g.id + ".opacity", [0.0, 1.0], [m.arcLight, light]))
    end for
    m.arcLight = light
    anim.control = "start"
end sub

sub onArcState()
    if m.arcAnim.state = "stopped" then nextArcStep()
end sub

' A short burst, a log popping, played now and then: each time shifted sideways along the logs and maybe
' mirrored, so no two pops look alike; the room flares as it starts.
sub addClip(group as object, layer as object)
    r = layer.rect
    files = []
    for frame = 0 to layer.frames - 1
        files.push(layer.file.Replace("%02d", Right("0" + frame.ToStr(), 2)))
    end for
    p = makeFrames(files, r[2], r[3])
    p.translation = [r[0], r[1]]
    p.scaleRotateCenter = [r[2] / 2, r[3]]
    p.visible = false
    group.appendChild(p)
    m.clip = { layer: layer, frames: p, frame: -1, clock: CreateObject("roTimespan") }
    m.clip.next = rndRange(layer.everySec)
    timer = CreateObject("roSGNode", "Timer")
    timer.repeat = true
    timer.duration = 1 / layer.fps
    timer.observeField("fire", "onClipTick")
    m.top.appendChild(timer)
    timer.control = "start"
end sub

sub onClipTick()
    c = m.clip
    layer = c.layer
    now = c.clock.TotalMilliseconds() / 1000
    if c.frame < 0
        if now < c.next then return
        c.frames.translation = [layer.rect[0] + rndRange(layer.shiftPx), layer.rect[1]]
        if Rnd(2) = 1 then c.frames.scale = [1.0, 1.0] else c.frames.scale = [-1.0, 1.0]
        c.frames.visible = true
        if m.flare <> invalid then m.flare.control = "start"
    end if
    was = c.frame
    c.frame = c.frame + 1
    if c.frame >= layer.frames
        showFrame(c.frames, was, -1)
        c.frames.visible = false
        c.frame = -1
        c.next = now + rndRange(layer.everySec)
        return
    end if
    showFrame(c.frames, was, c.frame)
end sub

' Now and then the fire's logs collapse: the layers give way to their fallen variants in half a second, the
' room flaring, and after a few minutes the fire is built up again, slowly. Wait, fall, hold, rebuild, wait...
' The waits are a Timer's, the changes an Animation's.
sub addCollapse()
    c = m.scene.collapse
    for each id in c.into
        m.world.findNode("collapse_" + id).opacity = 0
    end for
    m.collapseAnim = CreateObject("roSGNode", "Animation")
    m.collapseAnim.repeat = false
    m.collapseAnim.easeFunction = "inOutSine"
    m.top.appendChild(m.collapseAnim)
    m.collapseAnim.observeField("state", "onCollapseState")
    m.collapseTimer = CreateObject("roSGNode", "Timer")
    m.collapseTimer.repeat = false
    m.top.appendChild(m.collapseTimer)
    m.collapseTimer.observeField("fire", "onCollapseTimer")
    collapsePhase("wait")
end sub

sub collapsePhase(phase as string)
    c = m.scene.collapse
    m.collapsePhase = phase
    if phase = "wait" or phase = "hold"
        if phase = "wait" then m.collapseTimer.duration = rndRange(c.everySec) else m.collapseTimer.duration = rndRange(c.holdSec)
        m.collapseTimer.control = "start"
        return
    end if
    anim = m.collapseAnim
    while anim.getChildCount() > 0
        anim.removeChildIndex(0)
    end while
    if phase = "fall"
        anim.duration = 0.5
        standing = 0.0
        if m.flare <> invalid then m.flare.control = "start"
    else
        anim.duration = 20
        standing = 1.0
    end if
    for i = 0 to c.layers.count() - 1
        a = m.world.findNode("collapse_" + c.layers[i])
        b = m.world.findNode("collapse_" + c.into[i])
        anim.appendChild(interpolator("FloatFieldInterpolator", a.id + ".opacity", [0.0, 1.0], [1.0 - standing, standing]))
        anim.appendChild(interpolator("FloatFieldInterpolator", b.id + ".opacity", [0.0, 1.0], [standing, 1.0 - standing]))
    end for
    anim.control = "start"
end sub

sub onCollapseTimer()
    if m.collapsePhase = "wait" then collapsePhase("fall") else collapsePhase("rebuild")
end sub

sub onCollapseState()
    if m.collapseAnim.state <> "stopped" then return
    if m.collapsePhase = "fall" then collapsePhase("hold") else collapsePhase("wait")
end sub
