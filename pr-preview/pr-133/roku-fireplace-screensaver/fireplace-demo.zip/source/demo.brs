' Only in fireplace-demo.zip, never in the zip for the TV: brs-engine (and the simulator at
' https://lvcabral.com/brs) cannot start a screensaver, so this starts it as an ordinary channel.
sub Main()
    RunScreenSaver({})
end sub
